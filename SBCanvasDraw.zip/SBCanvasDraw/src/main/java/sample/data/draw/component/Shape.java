package sample.data.draw.component;

/**
 * @author Abhilash Ghosh
 * @since 1.0
 * @version 1.2
 */
public interface Shape {
    public String draw();
}
