package sample.data.draw.service;

public interface PortfolioService {

}