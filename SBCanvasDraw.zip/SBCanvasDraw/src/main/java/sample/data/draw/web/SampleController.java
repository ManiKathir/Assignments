/*
 * Copyright 2012-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sample.data.draw.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.data.draw.component.Canvas;
import sample.data.draw.component.Rectangle;
import sample.data.draw.component.Line;
import sample.data.draw.component.Fill;

@RestController
public class SampleController {
	
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String helloWorld() {
		return "WELCOME";
	} 	
	
	@RequestMapping(value="/canvas", method=RequestMethod.GET)
	public @ResponseBody String getCanvas(@RequestParam("x") int x, @RequestParam("y") int y) throws Exception{
	    System.out.println("canvas x="+x+" and y="+y);
		Canvas canvas = new Canvas(x,y);
		String drawing = canvas.draw();
		return drawing;
	}	

	@RequestMapping(value="/rectangle", method=RequestMethod.GET)
	public @ResponseBody String getRectangle(@RequestParam("x1") int x1, @RequestParam("y1") int y1,
										     @RequestParam("x2") int x2, @RequestParam("y2") int y2) throws Exception{
	    System.out.println("rectangle of (x1,y1)=("+x1+","+y1+") and (x2,y2)=("+x2+","+y2+")");
		Rectangle rectangle = new Rectangle(x1,y1,x2,y2);
		String drawing = rectangle.draw();
		return drawing;
	}
	
	@RequestMapping(value="/line", method=RequestMethod.GET)
	public @ResponseBody String getLine(@RequestParam("x1") int x1, @RequestParam("y1") int y1,
										     @RequestParam("x2") int x2, @RequestParam("y2") int y2) throws Exception{
		System.out.println("Line: Only aupports horizontal or vertical lines");									 
	    System.out.println("Line of (x1,y1)=("+x1+","+y1+") and (x2,y2)=("+x2+","+y2+")");
		Line line = new Line(x1,y1,x2,y2);
		String drawing = line.draw();
		return drawing;
	}

	@RequestMapping(value="/fill", method=RequestMethod.GET)
	public @ResponseBody String getFill(@RequestParam("x") String x, @RequestParam("y") String y,
										     @RequestParam("o") String color) throws Exception{									 
	    System.out.println("Fill x="+x+" and y="+y+"and color = "+color);
		Fill fill = new Fill(x,y,color);
		String drawing = fill.draw();
		return drawing;
	}	
	
}
