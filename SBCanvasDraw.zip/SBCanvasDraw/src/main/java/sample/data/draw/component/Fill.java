package sample.data.draw.component;


import sample.data.draw.exception.ValidationException;

/**
 * The fill component should fill the entire area connected to (x,y) with supplied color.
 * Validation Criteria:
 *          - It expects x and y co-ordinates and replacement color as args
 *
 * @author Abhilash Ghosh
 * @since 1.1
 * @version 1.2
 */
 //extends ShapeDecorator 
public class Fill {

    int x,y;
    String color;
	Canvas canvas;

    /**
     * Constructor to initialize the Fill component
     * @param args
     * @exception ValidationException
     */
    public Fill(String x1, String y1, String o) {
        //super(shape);

        // if(args.length != 3) {
            // throw new IllegalArgumentException("Invalid args supplied! Fill command accept 3 args: x y o");
        // }

        int x = Integer.parseInt(x1);
        int y = Integer.parseInt(y1);
        String color = o;
		
		canvas = new Canvas(x,y);	

        // if(x < 1 ||  x > getCanvas().getWIDTH()){
            // throw new ValidationException("Validation Exception: x:"+ x + " co-ordinates should be greater than 1 and less than canvas width: " + getCanvas().getWIDTH());
        // }

        // if(y < 1 ||  y > getCanvas().getHEIGHT()){
            // throw new ValidationException("Validation Exception: y:"+ y + " co-ordinates should be greater than 1 and less than canvas height: " + getCanvas().getHEIGHT());
        // }

        this.x = x;
        this.y = y;
        this.color = o;
    }

    public String draw() {
        floodFill(canvas.cells, x, y, CellContent.EMPTY.symbol, color);
		
		String drawing = canvas.draw();
		return drawing;
    }

    /**
     * Implementation of Flood fill algorithm. The flood-fill algorithm takes four parameters: x coordinate, x coordinate, a target color, and a replacement color.
     * The algorithm looks for all nodes in the array that are connected to the start node by a path of the target color and changes them to the replacement color.
     * @see <a href="https://en.wikipedia.org/wiki/Flood_fill">Flood Fill Algorithm</a>
     *
     * @param cells cells of the canvas
     * @param x starting x co-ordinate
     * @param y starting y co-ordinate
     * @param oldColor the color to be replaced
     * @param newColor the replacement color
     */
    private void floodFill(String cells[][], int x, int y, String oldColor, String newColor) {

        if (x < 0 || x >= canvas.COL+1 || y < 0 || y >= canvas.ROW+1)
            return;
        if (!oldColor.equals(cells[y][x]))
            return;

        // Replace the color at (x, y)
        cells[y][x] = newColor;
        // Recur for north, east, south and west
        floodFill(cells, x+1, y, oldColor, newColor);
        floodFill(cells, x-1, y, oldColor, newColor);
        floodFill(cells, x, y+1, oldColor, newColor);
        floodFill(cells, x, y-1, oldColor, newColor);
    }
}
